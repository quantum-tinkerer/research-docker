# Copyright (C) 2026 conda
# SPDX-License-Identifier: BSD-3-Clause
from __future__ import annotations

import json
import re
from types import SimpleNamespace
from typing import TYPE_CHECKING, cast

import pytest
import rattler
from conda import __version__ as _conda_version
from conda.base.context import reset_context
from conda.models.channel import Channel
from conda.models.records import PackageRecord, PrefixRecord

import conda_rattler_solver.utils as utils_module
from conda_rattler_solver.utils import notify_conda_outdated, rattler_build_string

if TYPE_CHECKING:
    from pathlib import Path

    from conda_rattler_solver.index import RattlerIndexHelper


class _FakeIndex:
    """Minimal stand-in for RattlerIndexHelper."""

    def __init__(self, channel_name: str, newer_records: list[PackageRecord]):
        self.channels = [SimpleNamespace(canonical_name=channel_name)]
        self._newer_records = newer_records

    def search(self, spec, search_expanded_index: bool = False):
        return self._newer_records


class _FakePrefixData:
    """Stand-in for conda.core.prefix_data.PrefixData"""

    def __init__(self, conda_self_installed: bool, is_frozen: bool = False):
        self._conda_self_installed = conda_self_installed
        self._is_frozen = is_frozen

    def __call__(self, *args, **kwargs) -> _FakePrefixData:
        return self

    def get(self, name, default=None):
        if name == "conda-self" and self._conda_self_installed:
            return PackageRecord(
                name="conda-self",
                version="1.0.0",
                build="pyh_0",
                build_number=0,
                channel="defaults",
                subdir="noarch",
                fn="conda-self-1.0.0-pyh_0.conda",
                md5="1" * 32,
            )
        return default

    def is_frozen(self) -> bool:
        return self._is_frozen


def _write_current_conda_prefix_record(conda_meta_dir, channel_name: str):
    conda_meta_dir.mkdir(parents=True, exist_ok=True)
    record = PrefixRecord(
        name="conda",
        version=_conda_version,
        build="py_0",
        build_number=0,
        channel=channel_name,
        subdir="noarch",
        fn=f"conda-{_conda_version}-py_0.conda",
        md5="0" * 32,
    )
    (conda_meta_dir / f"conda-{_conda_version}-py_0.json").write_text(json.dumps(record.dump()))


@pytest.mark.parametrize(
    "conda_self_installed,frozen,expected_snippet",
    [
        pytest.param(True, True, r"\$ conda self update\n", id="conda self installed, frozen"),
        pytest.param(
            True, False, r"\$ conda self update\n", id="conda self installed, not frozen"
        ),
        pytest.param(
            False,
            True,
            r"\$ conda update -n base -c [\w-]+ conda --override-frozen",
            id="conda self not installed, frozen",
        ),
        pytest.param(
            False,
            False,
            r"\$ conda update -n base -c [\w-]+ conda\n",
            id="conda self not installed, not frozen",
        ),
    ],
)
def test_notify_conda_outdated_message(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    conda_self_installed: bool,
    frozen: bool,
    expected_snippet: str,
) -> None:
    """
    Tests the notify conda outdated message.
    - 'conda self update' whenever the 'conda-self' plugin is installed
    - 'conda update ... --override-frozen' when 'conda-self' is absent and the prefix
        is frozen (a plain update is blocked in that case).
    - a plain 'conda update ...' when 'conda-self' is absent and the prefix isn't frozen.
    """

    channel_name = "test-channel"
    _write_current_conda_prefix_record(tmp_path / "conda-meta", channel_name)

    # Make conda "run from" our fake prefix, which contains the conda-meta record above.
    monkeypatch.setenv("CONDA_NOTIFY_OUTDATED_CONDA", "true")
    monkeypatch.setenv("CONDA_QUIET", "false")
    monkeypatch.setattr(utils_module, "PrefixData", _FakePrefixData(conda_self_installed, frozen))
    monkeypatch.setenv("CONDA_ROOT_PREFIX", str(tmp_path))
    reset_context()

    newer_record = PackageRecord(
        name="conda",
        version="99.0.0",
        build="py_0",
        build_number=0,
        channel=channel_name,
        subdir="noarch",
        fn="conda-99.0.0-py_0.conda",
        md5="2" * 32,
    )
    index = _FakeIndex(channel_name, [newer_record])

    # Use a target prefix different from context.conda_prefix so the "already updated
    # in this solve" short-circuit doesn't kick in.
    notify_conda_outdated(prefix=str(tmp_path), index=index, final_state=())

    stderr = capsys.readouterr().err
    assert "WARNING: A newer version of conda exists" in stderr
    assert re.search(expected_snippet, stderr)


@pytest.mark.usefixtures("solver_rattler")
@pytest.mark.parametrize(
    "spec,expected_name,expected_extras",
    [
        pytest.param("numpy", "numpy", None, id="name-only"),
        pytest.param("numpy=1.21", "numpy", None, id="fuzzy-version"),
        pytest.param("numpy==1.21.0=py39_0", "numpy", None, id="exact-version-build"),
        pytest.param("foo >=1.0,<2", "foo", None, id="version-inequality"),
        pytest.param("numpy[build=py39*]", "numpy", None, id="build-glob"),
        pytest.param("numpy=[build=0]", "numpy", None, id="name-equals-bracket"),
        pytest.param(
            "numpy=[extras=[a,b]]",
            "numpy",
            {"a", "b"},
            id="name-equals-bracket-with-extras",
        ),
        pytest.param(
            "ca-certificates[when='libzlib=1.2']",
            "ca-certificates",
            None,
            id="when",
        ),
        pytest.param(
            "requests[extras=[a,b]]",
            "requests",
            {"a", "b"},
            id="extras",
        ),
        pytest.param(
            "pkg[flags=[cuda]]",
            "pkg",
            None,
            id="flags",
        ),
    ],
)
def test_conda_match_spec_to_rattler_match_spec(
    spec: str,
    expected_name: str,
    expected_extras: set[str] | None,
) -> None:
    result = utils_module.conda_match_spec_to_rattler_match_spec(spec)
    assert result.name.normalized == expected_name
    if expected_extras is None:
        assert result.extras in (None, [])
    else:
        assert set(result.extras) == expected_extras


@pytest.mark.parametrize(
    "spec,expected",
    [
        pytest.param(
            'httpx[version="0.28.1",extras="cli"]',
            {"extras": {"cli"}, "version": "==0.28.1"},
            id="version-in-bracket",
        ),
        pytest.param(
            "httpx=0.28.1=py_0[extras=cli]",
            {"extras": {"cli"}, "version": "==0.28.1", "build": "py_0"},
            id="version-build-extras",
        ),
        pytest.param(
            'httpx>=0.28,<1[extras="cli,http2"]',
            {"extras": {"cli", "http2"}, "version": ">=0.28,<1"},
            id="version-range-multiple-extras",
        ),
        pytest.param(
            "httpx==0.28.1[extras=cli,when='python>=3.9']",
            {"extras": {"cli"}, "version": "==0.28.1", "condition": "python>=3.9"},
            id="version-extras-condition",
        ),
    ],
)
def test_conda_match_spec_to_rattler_match_spec_extras_keep_version_build_condition(
    spec: str,
    expected: dict,
) -> None:
    """Extras combined with a version/build/condition must keep all of them (#149)."""
    result = utils_module.conda_match_spec_to_rattler_match_spec(spec)
    actual = {"extras": set(result.extras), "version": result.version}
    if result.build:
        actual["build"] = result.build
    if result.condition:
        actual["condition"] = result.condition
    assert actual == expected


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("numpy=[build=0]", "numpy[build=0]"),
        ("requests[extras=['a', 'b']]", "requests[extras=['a', 'b']]"),
        ("pkg[flags=['cuda']]", "pkg[flags=['cuda']]"),
        ("numpy[build=0]", "numpy[build=0]"),
        ("numpy=[extras=[a,b]]", "numpy[extras=[a,b]]"),
    ],
)
def test_normalize_name_equals_bracket(raw: str, expected: str) -> None:
    assert utils_module._NAME_EQUALS_BRACKET.sub(r"\1[", raw, count=1) == expected


@pytest.mark.parametrize(
    "diagnostic_text,expected_str",
    (
        pytest.param("httpx[cli] ==0.28.0", "httpx==0.28.0", id="extra-and-version"),
        pytest.param("httpx[cli]", "httpx", id="extra-only"),
        pytest.param(
            "httpx[cli,http2] >=0.20,<1.0",
            "httpx[version='>=0.20,<1.0']",
            id="multiple-extras-and-version",
        ),
        pytest.param("httpx [extras=[cli],", "httpx", id="truncated-md5-diagnostic"),
        # Legitimate conda extras syntax must be preserved untouched.
        pytest.param(
            "httpx==0.28.0[extras=['cli']]",
            "httpx==0.28.0[extras=['cli']]",
            id="legitimate-conda-extras-untouched",
        ),
    ),
)
def test_matchspec_from_solver_diagnostic(
    monkeypatch: pytest.MonkeyPatch, diagnostic_text: str, expected_str: str
) -> None:
    monkeypatch.setenv("CONDA_SOLVER", "rattler")
    reset_context()
    assert str(utils_module.matchspec_from_solver_diagnostic(diagnostic_text)) == expected_str


@pytest.mark.parametrize("build", ["py313h1234567_0", "py3-none-any"])
def test_prefix_record_roundtrip_preserves_build(build: str) -> None:
    record = PrefixRecord(
        name="example",
        version="1.0",
        build=build,
        build_number=0,
        channel="https://conda.anaconda.org/conda-forge",
        subdir="noarch",
        fn=f"example-1.0-{build}.conda",
        url=f"https://conda.anaconda.org/conda-forge/noarch/example-1.0-{build}.conda",
    )

    rattler_record = utils_module.conda_prefix_record_to_rattler_prefix_record(record)
    result = utils_module.rattler_record_to_conda_record(rattler_record)

    assert result.build == build
    assert (result.name, result.version, result.build_number) == ("example", "1.0", 0)


def test_rattler_record_to_conda_record_restores_channel_from_cdn_url() -> None:
    auth_channel = "https://user:pass@example.com/conda/noarch"
    noauth_channel = "https://example.com/conda/noarch"
    package_url = "https://cdn.example.test/packages/noarch/example-1.0-0.tar.bz2"

    channel = Channel(auth_channel)
    info = SimpleNamespace(
        channel=channel,
        full_url=auth_channel,
        noauth_url=noauth_channel,
    )

    class _Index:
        def get_info(self, key: str):
            if key == info.noauth_url:
                return info
            raise KeyError(key)

    rattler_record = rattler.RepoDataRecord(
        package_record=rattler.PackageRecord(
            name="example",
            version="1.0",
            build=rattler_build_string("0"),
            build_number=0,
            subdir="noarch",
        ),
        file_name="example-1.0-0.tar.bz2",
        url=package_url,
        channel=noauth_channel,
    )

    conda_record = utils_module.rattler_record_to_conda_record(
        rattler_record, index=cast("RattlerIndexHelper", _Index())
    )

    assert conda_record.url == package_url
    assert conda_record.channel.url(with_credentials=True) == auth_channel
